﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace ChatApp {
    public partial class ChatForm : Form {
        private Socket clientSocket;
        private Thread receiveThread;
        public ChatForm() {
            InitializeComponent();
        }
        private void btnLogin_Click(object sender, EventArgs e) {
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            if (ConnectToServer(username, password)) {
                pnlLogin.Visible = false;
                pnlChat.Visible = true;
                receiveThread = new Thread(ReceiveMessages);
                receiveThread.IsBackground = true;
                receiveThread.Start();
            }
            else {
                MessageBox.Show("Invalid login or password.");
            }
        }
        private bool ConnectToServer(string username, string password) {
            try {
                clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                clientSocket.Connect("127.0.0.1", 8888);
                string credentials = $"{username}:{password}";
                byte[] data = Encoding.UTF8.GetBytes(credentials);
                clientSocket.Send(data);
                byte[] buffer = new byte[1024];
                int bytesRead = clientSocket.Receive(buffer);
                string response = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                return response == "OK";
            }
            catch {
                return false;
            }
        }
        private void ReceiveMessages() {
            try {
                while (true) {
                    byte[] buffer = new byte[1024];
                    int bytesRead = clientSocket.Receive(buffer);
                    if (bytesRead > 0) {
                        string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                        Invoke(new Action(() => listBoxMessages.Items.Add(message)));
                    }
                }
            }
            catch {
            }
        }
        private void btnSend_Click(object sender, EventArgs e) {
            string message = txtMessage.Text;
            string groupName = txtGroupNameInput.Text;
            if (message.StartsWith("/join") || message.StartsWith("/leave") || message.StartsWith("/msg")) {
                byte[] data = Encoding.UTF8.GetBytes(message);
                clientSocket.Send(data);
            }
            else {
                byte[] data = Encoding.UTF8.GetBytes($"/msg:{groupName}:{message}");
                clientSocket.Send(data);
            }

            txtMessage.Clear();
        }
        private void ChatForm_FormClosing(object sender, FormClosingEventArgs e) {
            if (clientSocket != null) {
                clientSocket.Shutdown(SocketShutdown.Both);
                clientSocket.Close();
                receiveThread.Abort();
            }
        }
        private void ChatForm_Load(object sender, EventArgs e) { }
        private void btnJoinGroup_Click(object sender, EventArgs e) {
            string groupName = txtGroupName.Text;
            string command = $"/join:{groupName}";
            byte[] data = Encoding.UTF8.GetBytes(command);
            clientSocket.Send(data);
            txtGroupName.Clear();
        }
        private void btnLeaveGroup_Click(object sender, EventArgs e) {
            string groupName = txtGroupName.Text;
            string command = $"/leave:{groupName}";
            byte[] data = Encoding.UTF8.GetBytes(command);
            clientSocket.Send(data);
            txtGroupName.Clear();
        }
    }
}

/*Пошаговая инструкция как создать решение в Visual Studio и подключить к нему серверное и клиентское(ие) 
приложения:
1.  Открыть Visual Studio: Запустить Visual Studio на компьютере.
2.  Создать новый проект: Выбрать "Файл" -> "Создать" -> "Новый проект" из главного меню.
3.  Выбрать тип проекта: В окне "Создать новый проект" выбрать тип проекта. Например "Windows Forms 
    (.NET Framework)".
4.  Указать имя и местоположение: Ввести имя для решения, выбрать местоположение и нажать кнопку "Создать".
5.  Добавить новые проекты к решению:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Добавить" -> "Новый проект";
	• добавить проект "Windows Forms App (.NET Framework)" для серверного и клиентского приложений, 
    и дать им соответствующие имена.
6.  Добавить код в каждый проект.
7.  Установить стартовые проекты:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Свойства";
	• в разделе "Общие" найти опцию "Несколько запускаемых проектов";
	• выбрать "Несколько запускаемых проектов" и установить для каждого проекта соответствующий статус 
    "Запуск", при необходимости изменить очерёдность их запуска.
8.  Запустить решение: Нажать F5 или выбрать "Отладка" -> "Запуск" из главного меню, чтобы запустить 
    решение.
9.  Окно сервера не отображается – запустить его в отдельном потоке:
    public ServerForm() {
        InitializeComponent();
        Task.Run(() => StartServer()); // запуск сервера в отдельном потоке
    }
10. Если исходный проект не нужен, удалить его из решения:
    • щёлкнуть правой кнопкой мыши на проекте в обозревателе решений и выбрать "Удалить";
    • удалить каталог (папку) проекта из каталога (папки) решения.*/

/*Для запуска нескольких ChatForm:
1. Открыть папку (директорию), содержащую проект.
2. Перейти …\ChatServer\bin\Debug и запустить файл ChatServer.exe -> нажать кнопку "Send".
3. Перейти …\ChatForm\bin\Debug и запустить файл ChatForm.exe -> ввести логин: Client1; 
   пароль: 1111 -> нажать кнопку "Login".
4. Повторить 3 раза запуск файла ChatForm.exe -> ввести логины: Client2, Client3 и Client4; 
   пароли: 2222, 3333 и 4444 соответственно -> каждый раз после ввода пароля нажимая кнопку 
   "Login".*/

/*Задание 1. Создайте оконное приложение «Чат». Для входа в чат пользователи указывают логин. 
Каждый пользователь видит все сообщения чата. Сообщения в чате могут быть только текстовыми.

Задание 2. Добавьте к первому заданию возможность регистрации по логину и паролю.

Задание 3. Добавьте возможность общения один на один. В этом режиме два пользователя посылают 
сообщения друг другу и никто, кроме них, их не видит.

Задание 4. Добавьте возможность создания комнат для общения. В комнате может находиться 
от 1 до N-пользователей.*/
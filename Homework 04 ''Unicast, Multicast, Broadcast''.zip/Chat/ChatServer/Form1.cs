﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChatApp {
    public partial class ServerForm : Form {
        private Socket serverSocket;
        private List<Socket> clients;
        private Dictionary<string, string> users;
        private Dictionary<string, List<Socket>> groups;
        public ServerForm() {
            InitializeComponent();
            clients = new List<Socket>();
            users = new Dictionary<string, string> {
                { "Client1", "1111" },
                { "Client2", "2222" },
                { "Client3", "3333" },
                { "Client4", "4444" }
            };
            groups = new Dictionary<string, List<Socket>>();
        }
        private async void btnStart_Click(object sender, EventArgs e) {
            serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            serverSocket.Bind(new IPEndPoint(IPAddress.Any, 8888));
            serverSocket.Listen(10);
            listBoxLogs.Items.Add("Server started...");
            while (true) {
                Socket clientSocket = await Task.Run(() => serverSocket.Accept());
                _ = Task.Run(() => HandleClientAsync(clientSocket));
            }
        }
        private async Task HandleClientAsync(Socket clientSocket) {
            byte[] buffer = new byte[1024];
            int bytesRead = clientSocket.Receive(buffer);
            string credentials = Encoding.UTF8.GetString(buffer, 0, bytesRead);
            string[] parts = credentials.Split(':');
            string username = parts[0];
            string password = parts[1];
            if (users.ContainsKey(username) && users[username] == password) {
                await clientSocket.SendAsync(new ArraySegment<byte>(Encoding.UTF8.GetBytes("OK")), SocketFlags.None);
                lock (clients) {
                    clients.Add(clientSocket);
                }
                listBoxLogs.Invoke((Action)(() => listBoxLogs.Items.Add($"{username} connected.")));
                await Task.Run(() => HandleChatAsync(clientSocket, username));
            }
            else {
                await clientSocket.SendAsync(new ArraySegment<byte>(Encoding.UTF8.GetBytes("FAIL")), SocketFlags.None);
                clientSocket.Shutdown(SocketShutdown.Both);
                clientSocket.Close();
            }
        }
        private async Task HandleChatAsync(Socket clientSocket, string username) {
            byte[] buffer = new byte[1024];
            while (true) {
                try {
                    int bytesRead = await clientSocket.ReceiveAsync(new ArraySegment<byte>(buffer), SocketFlags.None);
                    if (bytesRead > 0) {
                        string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                        string[] parts = message.Split(new char[] { ':' }, 3);
                        if (parts[0] == "/join") {
                            string groupName = parts[1];
                            JoinGroup(groupName, clientSocket);
                            BroadcastMessageToGroup($"{username} joined {groupName}", groupName, clientSocket);
                        }
                        else if (parts[0] == "/leave") {
                            string groupName = parts[1];
                            LeaveGroup(groupName, clientSocket);
                            BroadcastMessageToGroup($"{username} left {groupName}", groupName, clientSocket);
                        }
                        else if (parts[0] == "/msg") {
                            string groupName = parts[1];
                            string groupMessage = parts[2];
                            BroadcastMessageToGroup($"{username}: {groupMessage}", groupName, clientSocket);
                        }
                        else {
                            BroadcastMessage($"{username}: {message}", clientSocket);
                        }
                    }
                }
                catch {
                    lock (clients) {
                        clients.Remove(clientSocket);
                    }
                    clientSocket.Shutdown(SocketShutdown.Both);
                    clientSocket.Close();
                    listBoxLogs.Invoke((Action)(() => listBoxLogs.Items.Add($"{username} disconnected.")));
                    break;
                }
            }
        }
        private void JoinGroup(string groupName, Socket clientSocket) {
            if (!groups.ContainsKey(groupName)) {
                groups[groupName] = new List<Socket>();
            }
            if (!groups[groupName].Contains(clientSocket)) {
                groups[groupName].Add(clientSocket);
            }
        }
        private void LeaveGroup(string groupName, Socket clientSocket) {
            if (groups.ContainsKey(groupName)) {
                groups[groupName].Remove(clientSocket);
            }
        }
        private void BroadcastMessageToGroup(string message, string groupName, Socket senderSocket) {
            if (groups.ContainsKey(groupName)) {
                byte[] data = Encoding.UTF8.GetBytes(message);
                foreach (var client in groups[groupName]) {
                    if (client != senderSocket) {
                        client.Send(data);
                    }
                }
                listBoxLogs.Invoke((Action)(() => listBoxLogs.Items.Add($"Group {groupName}: {message}")));
            }
        }
        private void BroadcastMessage(string message, Socket senderSocket) {
            byte[] data = Encoding.UTF8.GetBytes(message);
            lock (clients) {
                foreach (var client in clients) {
                    if (client != senderSocket) {
                        client.Send(data);
                    }
                }
            }
            listBoxLogs.Invoke((Action)(() => listBoxLogs.Items.Add($"Broadcast: {message}")));
        }
    }
}

/*Пошаговая инструкция как создать решение в Visual Studio и подключить к нему серверное и клиентское(ие) 
приложения:
1.  Открыть Visual Studio: Запустить Visual Studio на компьютере.
2.  Создать новый проект: Выбрать "Файл" -> "Создать" -> "Новый проект" из главного меню.
3.  Выбрать тип проекта: В окне "Создать новый проект" выбрать тип проекта. Например "Windows Forms 
    (.NET Framework)".
4.  Указать имя и местоположение: Ввести имя для решения, выбрать местоположение и нажать кнопку "Создать".
5.  Добавить новые проекты к решению:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Добавить" -> "Новый проект";
	• добавить проект "Windows Forms App (.NET Framework)" для серверного и клиентского приложений, 
    и дать им соответствующие имена.
6.  Добавить код в каждый проект.
7.  Установить стартовые проекты:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Свойства";
	• в разделе "Общие" найти опцию "Несколько запускаемых проектов";
	• выбрать "Несколько запускаемых проектов" и установить для каждого проекта соответствующий статус 
    "Запуск", при необходимости изменить очерёдность их запуска.
8.  Запустить решение: Нажать F5 или выбрать "Отладка" -> "Запуск" из главного меню, чтобы запустить 
    решение.
9.  Окно сервера не отображается – запустить его в отдельном потоке:
    public ServerForm() {
        InitializeComponent();
        Task.Run(() => StartServer()); // запуск сервера в отдельном потоке
    }
10. Если исходный проект не нужен, удалить его из решения:
    • щёлкнуть правой кнопкой мыши на проекте в обозревателе решений и выбрать "Удалить";
    • удалить каталог (папку) проекта из каталога (папки) решения.*/

/*Для запуска нескольких ChatForm:
1. Открыть папку (директорию), содержащую проект.
2. Перейти …\ChatServer\bin\Debug и запустить файл ChatServer.exe -> нажать кнопку "Send".
3. Перейти …\ChatForm\bin\Debug и запустить файл ChatForm.exe -> ввести логин: Client1; 
   пароль: 1111 -> нажать кнопку "Login".
4. Повторить 3 раза запуск файла ChatForm.exe -> ввести логины: Client2, Client3 и Client4; 
   пароли: 2222, 3333 и 4444 соответственно -> каждый раз после ввода пароля нажимая кнопку 
   "Login".*/

/*Задание 1. Создайте оконное приложение «Чат». Для входа в чат пользователи указывают логин. 
Каждый пользователь видит все сообщения чата. Сообщения в чате могут быть только текстовыми.

Задание 2. Добавьте к первому заданию возможность регистрации по логину и паролю.

Задание 3. Добавьте возможность общения один на один. В этом режиме два пользователя посылают 
сообщения друг другу и никто, кроме них, их не видит.

Задание 4. Добавьте возможность создания комнат для общения. В комнате может находиться 
от 1 до N-пользователей.*/
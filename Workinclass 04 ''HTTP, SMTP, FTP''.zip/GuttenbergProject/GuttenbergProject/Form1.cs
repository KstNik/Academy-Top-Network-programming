﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;
using HtmlAgilityPack; /*!устанавливается с помощью NuGet Package Manager в Visual Studio, порядок действий
(c https://learn.microsoft.com/ru-ru/nuget/consume-packages/install-use-packages-visual-studio):
открыть этот проект в Visual Studio -> пункт меню «Проект» -> подпункт «Управление пакетами NuGet…» -> 
в открывшейся вкладке «NuGet: BookReader *» выбрать пункт меню «Обзор» -> в строке поиска заполнить 
HtmlAgilityPack -> в левом окне выбрать HtmlAgilityPack -> в правом окне нажать кнопку «Установить» -> 
в появившемся диалоговом окне «Просмотр изменений» нажать кнопку «OK»*/

namespace GuttenbergProject {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.MaximizeBox = false;
        }
        private async void btnLoad_Click(object sender, EventArgs e) {
            string url = "https://www.gutenberg.org/files/1524/1524-0.txt";
            txtText.Text = "Загрузка текста, пожалуйста подождите...";
            string hamletText = await LoadTextFromUrlAsync(url);
            txtText.Text = hamletText;
        }
        private async Task<string> LoadTextFromUrlAsync(string url) {
            using (HttpClient client = new HttpClient()) {
                try {
                    HttpResponseMessage response = await client.GetAsync(url);
                    response.EnsureSuccessStatusCode();
                    string responseBody = await response.Content.ReadAsStringAsync();
                    return responseBody;
                }
                catch (HttpRequestException e) {
                    return $"Ошибка при загрузке текста: {e.Message}";
                }
            }
        }
        private async void btnTop100_Click(object sender, EventArgs e) {
            string top100Url = "https://www.gutenberg.org/browse/scores/top";
            txtText.Text = "Загрузка списка книг, пожалуйста подождите...";
            List<Book> books = await LoadTop100BooksAsync(top100Url);
            lstTop100Books.Items.Clear();
            foreach (var book in books) {
                lstTop100Books.Items.Add(book);
            }
            txtText.Text = "";
        }
        private async Task<List<Book>> LoadTop100BooksAsync(string url) {
            List<Book> books = new List<Book>();
            using (HttpClient client = new HttpClient()) {
                try {
                    HttpResponseMessage response = await client.GetAsync(url);
                    response.EnsureSuccessStatusCode();
                    string responseBody = await response.Content.ReadAsStringAsync();
                    var htmlDoc = new HtmlAgilityPack.HtmlDocument();
                    htmlDoc.LoadHtml(responseBody);
                    var bookNodes = htmlDoc.DocumentNode.SelectNodes("//ol/li/a");
                    if (bookNodes != null) {
                        int count = 0;
                        foreach (var node in bookNodes) {
                            if (count >= 100) break;
                            string title = node.InnerText;
                            string bookUrl = "https://www.gutenberg.org" + node.GetAttributeValue("href", "");
                            books.Add(new Book { Title = title, Url = bookUrl });
                            count++;
                        }
                    }
                }
                catch (HttpRequestException e) {
                    txtText.Text = $"Ошибка при загрузке списка книг: {e.Message}";
                }
            }
            return books;
        }
        private async void lstTop100Books_SelectedIndexChanged(object sender, EventArgs e) {
            if (lstTop100Books.SelectedItem is Book selectedBook) {
                txtText.Text = "Загрузка текста, пожалуйста подождите...";
                string bookText = await LoadBookTextAsync(selectedBook.Url);
                txtText.Text = bookText;
            }
        }
        private async Task<string> LoadBookTextAsync(string bookPageUrl) {
            using (HttpClient client = new HttpClient()) {
                try {
                    HttpResponseMessage response = await client.GetAsync(bookPageUrl);
                    response.EnsureSuccessStatusCode();
                    string responseBody = await response.Content.ReadAsStringAsync();
                    var htmlDoc = new HtmlAgilityPack.HtmlDocument();
                    htmlDoc.LoadHtml(responseBody);
                    var linkNode = htmlDoc.DocumentNode.SelectSingleNode("//a[contains(@href, '.txt')]");
                    if (linkNode != null) {
                        string textUrl = "https://www.gutenberg.org" + linkNode.GetAttributeValue("href", "");
                        response = await client.GetAsync(textUrl);
                        response.EnsureSuccessStatusCode();
                        string bookText = await response.Content.ReadAsStringAsync();
                        return bookText;
                    }
                    else {
                        return "Текстовый файл не найден.";
                    }
                }
                catch (HttpRequestException e) {
                    return $"Ошибка при загрузке текста: {e.Message}";
                }
            }
        }
        private async void btnSearch_Click(object sender, EventArgs e) {
            string searchQuery = txtSearch.Text;
            string authorQuery = txtAuthor.Text;
            if (!string.IsNullOrWhiteSpace(searchQuery)) {
                txtText.Text = "Поиск книги, пожалуйста подождите...";
                string searchUrl = $"https://www.gutenberg.org/ebooks/search/?query={Uri.EscapeDataString(searchQuery)}";
                if (!string.IsNullOrWhiteSpace(authorQuery)) {
                    searchUrl += $" by {Uri.EscapeDataString(authorQuery)}";
                }
                string bookText = await SearchBookAsync(searchUrl);
                txtText.Text = bookText;
            }
        }
        private async Task<string> SearchBookAsync(string searchUrl) {
            using (HttpClient client = new HttpClient()) {
                try {
                    HttpResponseMessage response = await client.GetAsync(searchUrl);
                    response.EnsureSuccessStatusCode();
                    string responseBody = await response.Content.ReadAsStringAsync();
                    var htmlDoc = new HtmlAgilityPack.HtmlDocument();
                    htmlDoc.LoadHtml(responseBody);
                    var bookNode = htmlDoc.DocumentNode.SelectSingleNode("//li[@class='booklink']//a");
                    if (bookNode != null) {
                        string bookPageUrl = "https://www.gutenberg.org" + bookNode.GetAttributeValue("href", "");
                        return await LoadBookTextAsync(bookPageUrl);
                    }
                    else {
                        return "Книга не найдена.";
                    }
                }
                catch (HttpRequestException e) {
                    return $"Ошибка при поиске книги: {e.Message}";
                }
            }
        }
        public class Book {
            public string Title { get; set; }
            public string Url { get; set; }
            public override string ToString() {
                return Title;
            }
        }
    }
}

/*Задание 1. Создайте оконное приложение, которое по нажатию на кнопку загружает текст Гамлета 
Шекспира из https://www.gutenberg.org/.
Когда текст загружен, его нужно отобразить в приложении.
https://www.gutenberg.org/ – Проект Гуттенберга. Библиотека, в которой более 60000 бесплатных 
электронных книг.

Задание 2. Создайте оконное приложение, которое позволит, отобразить 100 самых популярных книг 
из библиотеки Гуттенберга. По нажатию на название книги нужно отобразить текст этой книги.

Задание 3. Создайте приложение для поиска информации в библиотеке Гуттенберга. Пользователь 
вводит текст для поиска (например, название книги), результаты поиска отображаются в 
интерфейсе приложения.*/
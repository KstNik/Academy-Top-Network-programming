﻿namespace GuttenbergProject
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtText = new System.Windows.Forms.TextBox();
            this.butLoad = new System.Windows.Forms.Button();
            this.btnTop100 = new System.Windows.Forms.Button();
            this.lstTop100Books = new System.Windows.Forms.ListBox();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtAuthor = new System.Windows.Forms.TextBox();
            this.labelText = new System.Windows.Forms.Label();
            this.labelTop100 = new System.Windows.Forms.Label();
            this.labelSearch = new System.Windows.Forms.Label();
            this.labelBook = new System.Windows.Forms.Label();
            this.labelAuthor = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtText
            // 
            this.txtText.Location = new System.Drawing.Point(12, 28);
            this.txtText.Multiline = true;
            this.txtText.Name = "txtText";
            this.txtText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtText.Size = new System.Drawing.Size(461, 454);
            this.txtText.TabIndex = 0;
            // 
            // butLoad
            // 
            this.butLoad.Location = new System.Drawing.Point(487, 9);
            this.butLoad.Name = "butLoad";
            this.butLoad.Size = new System.Drawing.Size(302, 23);
            this.butLoad.TabIndex = 1;
            this.butLoad.Text = "Загрузка книги Гамлет";
            this.butLoad.UseVisualStyleBackColor = true;
            this.butLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btnTop100
            // 
            this.btnTop100.Location = new System.Drawing.Point(486, 78);
            this.btnTop100.Name = "btnTop100";
            this.btnTop100.Size = new System.Drawing.Size(302, 23);
            this.btnTop100.TabIndex = 2;
            this.btnTop100.Text = "Отобразить 100 самых популярных книг";
            this.btnTop100.UseVisualStyleBackColor = true;
            this.btnTop100.Click += new System.EventHandler(this.btnTop100_Click);
            // 
            // lstTop100Books
            // 
            this.lstTop100Books.FormattingEnabled = true;
            this.lstTop100Books.Location = new System.Drawing.Point(486, 107);
            this.lstTop100Books.Name = "lstTop100Books";
            this.lstTop100Books.Size = new System.Drawing.Size(301, 251);
            this.lstTop100Books.TabIndex = 3;
            this.lstTop100Books.SelectedIndexChanged += new System.EventHandler(this.lstTop100Books_SelectedIndexChanged);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(579, 407);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(210, 20);
            this.txtSearch.TabIndex = 4;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(486, 459);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(301, 23);
            this.btnSearch.TabIndex = 5;
            this.btnSearch.Text = "Искать книгу";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtAuthor
            // 
            this.txtAuthor.Location = new System.Drawing.Point(615, 433);
            this.txtAuthor.Name = "txtAuthor";
            this.txtAuthor.Size = new System.Drawing.Size(174, 20);
            this.txtAuthor.TabIndex = 6;
            // 
            // labelText
            // 
            this.labelText.AutoSize = true;
            this.labelText.Location = new System.Drawing.Point(12, 9);
            this.labelText.Name = "labelText";
            this.labelText.Size = new System.Drawing.Size(69, 13);
            this.labelText.TabIndex = 7;
            this.labelText.Text = "Текст книги";
            // 
            // labelTop100
            // 
            this.labelTop100.AutoSize = true;
            this.labelTop100.Location = new System.Drawing.Point(483, 57);
            this.labelTop100.Name = "labelTop100";
            this.labelTop100.Size = new System.Drawing.Size(305, 13);
            this.labelTop100.TabIndex = 8;
            this.labelTop100.Text = "Для просмотра содержимого книги выберите её в списке";
            // 
            // labelSearch
            // 
            this.labelSearch.AutoSize = true;
            this.labelSearch.Location = new System.Drawing.Point(484, 386);
            this.labelSearch.Name = "labelSearch";
            this.labelSearch.Size = new System.Drawing.Size(282, 13);
            this.labelSearch.TabIndex = 9;
            this.labelSearch.Text = "Для поиска книги – обязательно заполните все поля!";
            // 
            // labelBook
            // 
            this.labelBook.AutoSize = true;
            this.labelBook.Location = new System.Drawing.Point(484, 410);
            this.labelBook.Name = "labelBook";
            this.labelBook.Size = new System.Drawing.Size(89, 13);
            this.labelBook.TabIndex = 10;
            this.labelBook.Text = "Название книги";
            // 
            // labelAuthor
            // 
            this.labelAuthor.AutoSize = true;
            this.labelAuthor.Location = new System.Drawing.Point(484, 436);
            this.labelAuthor.Name = "labelAuthor";
            this.labelAuthor.Size = new System.Drawing.Size(125, 13);
            this.labelAuthor.TabIndex = 11;
            this.labelAuthor.Text = "Имя и фамилия автора";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 493);
            this.Controls.Add(this.labelAuthor);
            this.Controls.Add(this.labelBook);
            this.Controls.Add(this.labelSearch);
            this.Controls.Add(this.labelTop100);
            this.Controls.Add(this.labelText);
            this.Controls.Add(this.txtAuthor);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.lstTop100Books);
            this.Controls.Add(this.btnTop100);
            this.Controls.Add(this.butLoad);
            this.Controls.Add(this.txtText);
            this.Name = "Form1";
            this.Text = "Guttenberg Project";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtText;
        private System.Windows.Forms.Button butLoad;
        private System.Windows.Forms.Button btnTop100;
        private System.Windows.Forms.ListBox lstTop100Books;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtAuthor;
        private System.Windows.Forms.Label labelText;
        private System.Windows.Forms.Label labelTop100;
        private System.Windows.Forms.Label labelSearch;
        private System.Windows.Forms.Label labelBook;
        private System.Windows.Forms.Label labelAuthor;
    }
}


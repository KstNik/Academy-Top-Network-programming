﻿using System;
using System.Net.Sockets;
using System.Text;

namespace ClientApp {
    class Program {
        private const string serverIP = "127.0.0.1";
        private const int port = 8888;
        static void Main(string[] args) {
            try {
                Console.WriteLine("Для запроса текущей даты введите 'D', времени - 'T', выход - 'Q'.");
                while (true) {
                    using (TcpClient client = new TcpClient()) {
                        ConsoleKeyInfo key = Console.ReadKey();
                        Console.WriteLine();
                        if (key.KeyChar == 'Q' || key.KeyChar == 'q') {
                            break;
                        }
                        else if (key.KeyChar == 'D' || key.KeyChar == 'd' || key.KeyChar == 'T' || key.KeyChar == 't') {
                            client.Connect(serverIP, port);
                            SendRequest(client, key.KeyChar == 'D' || key.KeyChar == 'd' ? "DATE" : "TIME");
                            client.Close();
                        }
                        else {
                            Console.WriteLine("Некорректный ввод. Пожалуйста, введите 'D', 'T' или 'Q'.");
                        }
                    }
                }
            }
            catch (Exception ex) {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
        }
        static void SendRequest(TcpClient client, string request) {
            try {
                NetworkStream stream = client.GetStream();
                byte[] data = Encoding.Unicode.GetBytes(request);
                stream.Write(data, 0, data.Length);
                Console.WriteLine($"Запрошено {request.ToLower()}.");
                data = new byte[1024];
                int bytesRead = stream.Read(data, 0, data.Length);
                string response = Encoding.Unicode.GetString(data, 0, bytesRead);
                Console.WriteLine($"Получено {request.ToLower()} от сервера: {response}");
            }
            catch (Exception ex) {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
        }
    }
}

/*Пошаговая инструкция как создать решение в Visual Studio и подключить к нему серверное и клиентское(ие) 
приложения:
1.  Открыть Visual Studio: Запустить Visual Studio на компьютере.
2.  Создать новый проект: Выбрать "Файл" -> "Создать" -> "Новый проект" из главного меню.
3.  Выбрать тип проекта: В окне "Создать новый проект" выбрать тип проекта. Например "Windows Forms 
    (.NET Framework)".
4.  Указать имя и местоположение: Ввести имя для решения, выбрать местоположение и нажать кнопку "Создать".
5.  Добавить новые проекты к решению:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Добавить" -> "Новый проект";
	• добавить проект "Windows Forms App (.NET Framework)" для серверного и клиентского приложений, 
    и дать им соответствующие имена.
6.  Добавить код в каждый проект.
7.  Установить стартовые проекты:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Свойства";
	• в разделе "Общие" найти опцию "Несколько запускаемых проектов";
	• выбрать "Несколько запускаемых проектов" и установить для каждого проекта соответствующий статус 
    "Запуск", при необходимости изменить очерёдность их запуска.
8.  Запустить решение: Нажать F5 или выбрать "Отладка" -> "Запуск" из главного меню, чтобы запустить 
    решение.
9.  Окно сервера не отображается – запустить его в отдельном потоке:
    public ServerForm() {
        InitializeComponent();
        Task.Run(() => StartServer()); // запуск сервера в отдельном потоке
    }
10. Если исходный проект не нужен, удалить его из решения:
    • щёлкнуть правой кнопкой мыши на проекте в обозревателе решений и выбрать "Удалить";
    • удалить каталог (папку) проекта из каталога (папки) решения.*/

/*Задание 2. Разработайте набор консольных приложений. Первое приложение: серверное приложение, которое на запросы клиента возвращает текущее время или дату на сервере. Второе приложение: клиентское приложение, запрашивающее дату или время. Пользователь с клавиатуры определяет, что нужно запросить. После отсылки даты или времени сервер разрывает соединение. Клиентское приложение отображает полученные данные.
Используйте механизм синхронных сокетов.*/
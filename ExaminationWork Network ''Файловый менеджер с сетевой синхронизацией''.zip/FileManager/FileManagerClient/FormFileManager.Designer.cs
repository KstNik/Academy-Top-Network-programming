﻿namespace FileManagerClient
{
    partial class FormFileManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnSelectFiles = new System.Windows.Forms.Button();
            this.btnUploadFiles = new System.Windows.Forms.Button();
            this.lstFiles = new System.Windows.Forms.ListBox();
            this.btnDownloadFiles = new System.Windows.Forms.Button();
            this.groupBox = new System.Windows.Forms.GroupBox();
            this.rbShareFolder = new System.Windows.Forms.RadioButton();
            this.rbOwnFolder = new System.Windows.Forms.RadioButton();
            this.btnClearList = new System.Windows.Forms.Button();
            this.lstFilesServer = new System.Windows.Forms.ListBox();
            this.serverFilesTimer = new System.Windows.Forms.Timer(this.components);
            this.btnDeleteFiles = new System.Windows.Forms.Button();
            this.chkAutoSave = new System.Windows.Forms.CheckBox();
            this.autoSaveTimer = new System.Windows.Forms.Timer(this.components);
            this.labelComputer = new System.Windows.Forms.Label();
            this.labelServer = new System.Windows.Forms.Label();
            this.groupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSelectFiles
            // 
            this.btnSelectFiles.Location = new System.Drawing.Point(89, 6);
            this.btnSelectFiles.Name = "btnSelectFiles";
            this.btnSelectFiles.Size = new System.Drawing.Size(110, 23);
            this.btnSelectFiles.TabIndex = 0;
            this.btnSelectFiles.Text = "Выбор файлов";
            this.btnSelectFiles.UseVisualStyleBackColor = true;
            this.btnSelectFiles.Click += new System.EventHandler(this.btnSelectFiles_Click);
            // 
            // btnUploadFiles
            // 
            this.btnUploadFiles.Location = new System.Drawing.Point(205, 6);
            this.btnUploadFiles.Name = "btnUploadFiles";
            this.btnUploadFiles.Size = new System.Drawing.Size(110, 23);
            this.btnUploadFiles.TabIndex = 1;
            this.btnUploadFiles.Text = "Загрузка файлов";
            this.btnUploadFiles.UseVisualStyleBackColor = true;
            this.btnUploadFiles.Click += new System.EventHandler(this.btnUploadFiles_Click);
            // 
            // lstFiles
            // 
            this.lstFiles.FormattingEnabled = true;
            this.lstFiles.Location = new System.Drawing.Point(12, 60);
            this.lstFiles.Name = "lstFiles";
            this.lstFiles.Size = new System.Drawing.Size(312, 368);
            this.lstFiles.TabIndex = 2;
            // 
            // btnDownloadFiles
            // 
            this.btnDownloadFiles.Location = new System.Drawing.Point(422, 4);
            this.btnDownloadFiles.Name = "btnDownloadFiles";
            this.btnDownloadFiles.Size = new System.Drawing.Size(110, 23);
            this.btnDownloadFiles.TabIndex = 3;
            this.btnDownloadFiles.Text = "Получение файлов";
            this.btnDownloadFiles.UseVisualStyleBackColor = true;
            this.btnDownloadFiles.Click += new System.EventHandler(this.btnDownloadFiles_Click);
            // 
            // groupBox
            // 
            this.groupBox.Controls.Add(this.rbShareFolder);
            this.groupBox.Controls.Add(this.rbOwnFolder);
            this.groupBox.Location = new System.Drawing.Point(376, 33);
            this.groupBox.Name = "groupBox";
            this.groupBox.Size = new System.Drawing.Size(272, 23);
            this.groupBox.TabIndex = 4;
            this.groupBox.TabStop = false;
            this.groupBox.Text = "Выбор папки";
            // 
            // rbShareFolder
            // 
            this.rbShareFolder.AutoSize = true;
            this.rbShareFolder.Location = new System.Drawing.Point(180, -2);
            this.rbShareFolder.Name = "rbShareFolder";
            this.rbShareFolder.Size = new System.Drawing.Size(93, 17);
            this.rbShareFolder.TabIndex = 1;
            this.rbShareFolder.TabStop = true;
            this.rbShareFolder.Text = "Общая папка";
            this.rbShareFolder.UseVisualStyleBackColor = true;
            this.rbShareFolder.CheckedChanged += new System.EventHandler(this.rbShareFolder_CheckedChanged);
            // 
            // rbOwnFolder
            // 
            this.rbOwnFolder.AutoSize = true;
            this.rbOwnFolder.Checked = true;
            this.rbOwnFolder.Location = new System.Drawing.Point(91, -2);
            this.rbOwnFolder.Name = "rbOwnFolder";
            this.rbOwnFolder.Size = new System.Drawing.Size(83, 17);
            this.rbOwnFolder.TabIndex = 0;
            this.rbOwnFolder.TabStop = true;
            this.rbOwnFolder.Text = "Своя папка";
            this.rbOwnFolder.UseVisualStyleBackColor = true;
            this.rbOwnFolder.CheckedChanged += new System.EventHandler(this.rbOwnFolder_CheckedChanged);
            // 
            // btnClearList
            // 
            this.btnClearList.Location = new System.Drawing.Point(205, 31);
            this.btnClearList.Name = "btnClearList";
            this.btnClearList.Size = new System.Drawing.Size(110, 23);
            this.btnClearList.TabIndex = 5;
            this.btnClearList.Text = "Очистка списка";
            this.btnClearList.UseVisualStyleBackColor = true;
            this.btnClearList.Click += new System.EventHandler(this.btnClearList_Click);
            // 
            // lstFilesServer
            // 
            this.lstFilesServer.FormattingEnabled = true;
            this.lstFilesServer.Location = new System.Drawing.Point(336, 60);
            this.lstFilesServer.Name = "lstFilesServer";
            this.lstFilesServer.Size = new System.Drawing.Size(312, 368);
            this.lstFilesServer.TabIndex = 6;
            // 
            // serverFilesTimer
            // 
            this.serverFilesTimer.Enabled = true;
            this.serverFilesTimer.Interval = 10000;
            this.serverFilesTimer.Tick += new System.EventHandler(this.serverFilesTimer_Tick);
            // 
            // btnDeleteFiles
            // 
            this.btnDeleteFiles.Location = new System.Drawing.Point(538, 4);
            this.btnDeleteFiles.Name = "btnDeleteFiles";
            this.btnDeleteFiles.Size = new System.Drawing.Size(110, 23);
            this.btnDeleteFiles.TabIndex = 7;
            this.btnDeleteFiles.Text = "Удаление файлов";
            this.btnDeleteFiles.UseVisualStyleBackColor = true;
            this.btnDeleteFiles.Click += new System.EventHandler(this.btnDeleteFiles_Click);
            // 
            // chkAutoSave
            // 
            this.chkAutoSave.AutoSize = true;
            this.chkAutoSave.Location = new System.Drawing.Point(89, 35);
            this.chkAutoSave.Name = "chkAutoSave";
            this.chkAutoSave.Size = new System.Drawing.Size(109, 17);
            this.chkAutoSave.TabIndex = 8;
            this.chkAutoSave.Text = "Автосохранение";
            this.chkAutoSave.UseVisualStyleBackColor = true;
            this.chkAutoSave.CheckedChanged += new System.EventHandler(this.chkAutoSave_CheckedChanged);
            // 
            // autoSaveTimer
            // 
            this.autoSaveTimer.Interval = 20000;
            this.autoSaveTimer.Tick += new System.EventHandler(this.autoSaveTimer_Tick);
            // 
            // labelComputer
            // 
            this.labelComputer.AutoSize = true;
            this.labelComputer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelComputer.Location = new System.Drawing.Point(9, 9);
            this.labelComputer.Name = "labelComputer";
            this.labelComputer.Size = new System.Drawing.Size(74, 13);
            this.labelComputer.TabIndex = 9;
            this.labelComputer.Text = "Компьютер";
            // 
            // labelServer
            // 
            this.labelServer.AutoSize = true;
            this.labelServer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelServer.Location = new System.Drawing.Point(358, 6);
            this.labelServer.Name = "labelServer";
            this.labelServer.Size = new System.Drawing.Size(50, 13);
            this.labelServer.TabIndex = 10;
            this.labelServer.Text = "Сервер";
            // 
            // FormFileManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(657, 439);
            this.Controls.Add(this.labelServer);
            this.Controls.Add(this.labelComputer);
            this.Controls.Add(this.chkAutoSave);
            this.Controls.Add(this.btnDeleteFiles);
            this.Controls.Add(this.lstFilesServer);
            this.Controls.Add(this.btnClearList);
            this.Controls.Add(this.groupBox);
            this.Controls.Add(this.btnDownloadFiles);
            this.Controls.Add(this.lstFiles);
            this.Controls.Add(this.btnUploadFiles);
            this.Controls.Add(this.btnSelectFiles);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FormFileManager";
            this.Text = "FileManager";
            this.groupBox.ResumeLayout(false);
            this.groupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSelectFiles;
        private System.Windows.Forms.Button btnUploadFiles;
        private System.Windows.Forms.ListBox lstFiles;
        private System.Windows.Forms.Button btnDownloadFiles;
        private System.Windows.Forms.GroupBox groupBox;
        private System.Windows.Forms.RadioButton rbShareFolder;
        private System.Windows.Forms.RadioButton rbOwnFolder;
        private System.Windows.Forms.Button btnClearList;
        private System.Windows.Forms.ListBox lstFilesServer;
        private System.Windows.Forms.Timer serverFilesTimer;
        private System.Windows.Forms.Button btnDeleteFiles;
        private System.Windows.Forms.CheckBox chkAutoSave;
        private System.Windows.Forms.Timer autoSaveTimer;
        private System.Windows.Forms.Label labelComputer;
        private System.Windows.Forms.Label labelServer;
    }
}
﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace FileManagerClient {
    public partial class FormRegistration : Form {
        private TcpClient client;
        private NetworkStream stream;
        public FormRegistration() {
            InitializeComponent();
        }
        private void btnRegister_Click(object sender, EventArgs e) {
            string login = txtLogin.Text;
            string password = txtPassword.Text;
            string responseMessage = SendRequest($"REGISTER {login} {password}");
            if (responseMessage == "REGISTERED") {
                MessageBox.Show("Регистрация успешна!");
                OpenFileManager(login);
            }
            else if (responseMessage == "USER_EXISTS") {
                MessageBox.Show("Пользователь уже существует!");
            }
            else if (responseMessage == "INVALID_USERNAME") {
                MessageBox.Show("Указанное имя недопустимо!");
            }
        }
        private void btnLogin_Click(object sender, EventArgs e) {
            string login = txtLogin.Text;
            string password = txtPassword.Text;
            string responseMessage = SendRequest($"LOGIN {login} {password}");
            if (responseMessage == "LOGIN_SUCCESS") {
                MessageBox.Show("Авторизация успешна!");
                OpenFileManager(login);
            }
            else if (responseMessage == "LOGIN_FAIL") {
                MessageBox.Show("Имя пользователя или пароль неверны!");
            }
        }
        private string SendRequest(string request) {
            if (client == null) {
                client = new TcpClient("127.0.0.1", 8888);
                stream = client.GetStream();
            }
            byte[] data = Encoding.UTF8.GetBytes(request);
            stream.Write(data, 0, data.Length);
            byte[] response = new byte[256];
            int bytesRead = stream.Read(response, 0, response.Length);
            return Encoding.UTF8.GetString(response, 0, bytesRead);
        }
        private void OpenFileManager(string username) {
            this.Hide();
            FormFileManager fileManager = new FormFileManager(username, client, stream);
            fileManager.ShowDialog();
            this.Close();
        }
    }
}
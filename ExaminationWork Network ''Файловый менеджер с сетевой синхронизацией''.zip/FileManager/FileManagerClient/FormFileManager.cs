﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Windows.Forms;

namespace FileManagerClient {
    public partial class FormFileManager : Form {
        private string username;
        private TcpClient client;
        private NetworkStream stream;
        public FormFileManager(string username, TcpClient client, NetworkStream stream) {
            InitializeComponent();
            this.username = username;
            this.client = client;
            this.stream = stream;
            // Привязка обработчиков событий к радиокнопкам
            rbOwnFolder.CheckedChanged += rbOwnFolder_CheckedChanged;
            rbShareFolder.CheckedChanged += rbShareFolder_CheckedChanged;
            // Привязка обработчика события для CheckBox
            chkAutoSave.CheckedChanged += chkAutoSave_CheckedChanged;
            // Привязка обработчика события для Timer
            autoSaveTimer.Tick += autoSaveTimer_Tick;
            // Загружаем файлы с сервера при открытии окна
            LoadFilesFromServer();
        }
        private void btnSelectFiles_Click(object sender, EventArgs e) {
            OpenFileDialog openFileDialog = new OpenFileDialog {
                Multiselect = true
            };
            if (openFileDialog.ShowDialog() == DialogResult.OK) {
                foreach (string file in openFileDialog.FileNames) {
                    if (!lstFiles.Items.Contains(file)) {
                        lstFiles.Items.Add(file);
                    }
                }
            }
        }
        private void btnUploadFiles_Click(object sender, EventArgs e) {
            if (lstFiles.Items.Count == 0) {
                MessageBox.Show("Нет файлов для загрузки.");
                return;
            }
            string targetDirectory = rbOwnFolder.Checked ? username : "Share";
            foreach (string filePath in lstFiles.Items) {
                byte[] fileData = File.ReadAllBytes(filePath);
                string fileName = Path.GetFileName(filePath);
                string header = $"UPLOAD {targetDirectory} {fileName} ";
                byte[] headerData = Encoding.UTF8.GetBytes(header);
                byte[] dataToSend = new byte[headerData.Length + fileData.Length];
                Buffer.BlockCopy(headerData, 0, dataToSend, 0, headerData.Length);
                Buffer.BlockCopy(fileData, 0, dataToSend, headerData.Length, fileData.Length);
                stream.Write(dataToSend, 0, dataToSend.Length);
            }
            if (!chkAutoSave.Checked) {
                MessageBox.Show("Файлы успешно загружены!");
            }
        }
        private void LoadFilesFromServer() {
            // Отправка запроса на сервер для получения списка файлов
            string targetDirectory = rbOwnFolder.Checked ? username : "Share";
            string request = $"LIST_FILES {targetDirectory}";
            byte[] requestBytes = Encoding.UTF8.GetBytes(request);
            stream.Write(requestBytes, 0, requestBytes.Length);
            // Чтение ответа от сервера
            byte[] buffer = new byte[1024];
            int bytesRead = stream.Read(buffer, 0, buffer.Length);
            string response = Encoding.UTF8.GetString(buffer, 0, bytesRead);
            // Очистка списока перед добавлением новых файлов
            lstFilesServer.Items.Clear();
            if (string.IsNullOrEmpty(response.Trim())) {
                MessageBox.Show("Нет файлов на сервере.");
                return;
            }
            // Разбивка ответа на имена файлов и добавление их в список
            string[] files = response.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string file in files) {
                lstFilesServer.Items.Add(file);
            }
        }
        private void btnDownloadFiles_Click(object sender, EventArgs e) {
            if (lstFilesServer.Items.Count == 0 || lstFilesServer.SelectedItem == null) {
                MessageBox.Show("Файлы для загрузки не выбраны.");
                return;
            }
            string selectedFile = lstFilesServer.SelectedItem.ToString();
            string targetDirectory = rbShareFolder.Checked ? "Share" : username;  // Проверяем, выбрана ли папка Share
            string request = $"DOWNLOAD {targetDirectory} {selectedFile}";
            byte[] data = Encoding.UTF8.GetBytes(request);
            stream.Write(data, 0, data.Length);
            // Чтение файла с сервера
            byte[] buffer = new byte[1024];
            MemoryStream ms = new MemoryStream();
            int bytesRead;
            while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0) {
                ms.Write(buffer, 0, bytesRead);
                if (bytesRead < buffer.Length)
                    break; // Завершение передачи
            }
            byte[] fileData = ms.ToArray();
            if (fileData.Length > 0 && Encoding.UTF8.GetString(fileData).Trim() != "FILE_NOT_FOUND") {
                SaveFileDialog saveFileDialog = new SaveFileDialog {
                    FileName = selectedFile
                };
                if (saveFileDialog.ShowDialog() == DialogResult.OK) {
                    File.WriteAllBytes(saveFileDialog.FileName, fileData);
                    MessageBox.Show("Файл успешно загружен!");
                }
            }
            else {
                MessageBox.Show("Файл не найден на сервере.");
            }
        }
        private void btnClearList_Click(object sender, EventArgs e) {
            lstFiles.Items.Clear();
        }
        private void serverFilesTimer_Tick(object sender, EventArgs e) {
            LoadFilesFromServer();
        }
        private void btnDeleteFiles_Click(object sender, EventArgs e) {
            if (lstFilesServer.SelectedItem == null) {
                MessageBox.Show("Выберите файл для удаления.");
                return;
            }
            string selectedFile = lstFilesServer.SelectedItem.ToString();
            string request;
            // Проверка, какая папка выбрана (своя или общая)
            if (rbOwnFolder.Checked) {
                request = $"DELETE {username} {selectedFile}";
            }
            else {
                request = $"DELETE Share {selectedFile}";
            }
            byte[] requestBytes = Encoding.UTF8.GetBytes(request);
            stream.Write(requestBytes, 0, requestBytes.Length);
            // Получение ответа от сервера
            byte[] responseBytes = new byte[256];
            int bytesRead = stream.Read(responseBytes, 0, responseBytes.Length);
            string response = Encoding.UTF8.GetString(responseBytes, 0, bytesRead);
            if (response == "DELETE_SUCCESS") {
                MessageBox.Show("Файл успешно удалён.");
                LoadFilesFromServer();  // Обновляние списка файлов на сервере
            }
            else {
                MessageBox.Show("Ошибка удаления файла или этот файл удалять запрещено!");
            }
        }
        private void rbOwnFolder_CheckedChanged(object sender, EventArgs e) {
            if (rbOwnFolder.Checked) {
                LoadFilesFromServer();
            }
        }
        private void rbShareFolder_CheckedChanged(object sender, EventArgs e) {
            if (rbShareFolder.Checked) {
                LoadFilesFromServer();
            }
        }
        private void chkAutoSave_CheckedChanged(object sender, EventArgs e) {
            if (chkAutoSave.Checked) {
                btnUploadFiles.Enabled = false; // Блокировка кнопки
                autoSaveTimer.Start(); // Запуск таймера
            }
            else {
                btnUploadFiles.Enabled = true; // Разблокировка кнопки
                autoSaveTimer.Stop(); // Останавливка таймера
            }
        }
        private void autoSaveTimer_Tick(object sender, EventArgs e) {
            // Загрузка файлов с клиента на сервер
            btnUploadFiles_Click(sender, e);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using Newtonsoft.Json;

namespace FileManagerServer {
    class Program {
        static string usersFilePath = "users.json";
        static void Main(string[] args) {
            // Создание папки "Share" если она не существует
            string shareDirectory = Path.Combine("Users", "Share");
            if (!Directory.Exists(shareDirectory)) {
                Directory.CreateDirectory(shareDirectory);
                Console.WriteLine("Папка 'Share' создана.");
                // Создание файла Share.txt
                string shareFilePath = Path.Combine(shareDirectory, "Share.txt");
                File.WriteAllText(shareFilePath, "Это общая папка предназначена для обмена файлами.");
            }
            TcpListener server = null;
            try {
                int port = 8888;
                IPAddress localAddr = IPAddress.Parse("127.0.0.1");
                server = new TcpListener(localAddr, port);
                server.Start();
                Console.WriteLine("Сервер запущен. Ожидание подключений...");
                while (true) {
                    TcpClient client = server.AcceptTcpClient();
                    Console.WriteLine("Подключен клиент.");
                    try {
                        NetworkStream stream = client.GetStream();
                        while (true) {
                            byte[] buffer = new byte[1024];
                            int bytesRead = stream.Read(buffer, 0, buffer.Length);
                            if (bytesRead == 0) {
                                break; // Клиент разорвал соединение
                            }
                            string request = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                            if (request.StartsWith("REGISTER")) {
                                HandleRegister(request, stream);
                            }
                            else if (request.StartsWith("LOGIN")) {
                                HandleLogin(request, stream);
                            }
                            else if (request.StartsWith("UPLOAD")) {
                                HandleUpload(request, stream);
                            }
                            else if (request.StartsWith("LIST_FILES")) {
                                HandleListFiles(request, stream);
                            }
                            else if (request.StartsWith("DOWNLOAD")) {
                                HandleDownload(request, stream);
                            }
                            else if (request.StartsWith("DELETE")) {
                                HandleDelete(request, stream);
                            }
                        }
                    }
                    catch (IOException ex) {
                        Console.WriteLine($"Ошибка ввода-вывода: {ex.Message}");
                    }
                    finally {
                        client.Close();
                    }
                }
            }
            catch (SocketException e) {
                Console.WriteLine($"SocketException: {e}");
            }
            finally {
                server?.Stop();
            }
            Console.WriteLine("\nНажмите Enter для завершения...");
            Console.Read();
        }
        static void HandleRegister(string request, NetworkStream stream) {
            string[] parts = request.Split(' ');
            string username = parts[1];
            string password = parts[2];
            if (username.ToLower() == "share") {
                byte[] response = Encoding.UTF8.GetBytes("INVALID_USERNAME");
                stream.Write(response, 0, response.Length);
                return;
            }
            var users = LoadUsers();
            if (users.ContainsKey(username)) {
                byte[] response = Encoding.UTF8.GetBytes("USER_EXISTS");
                stream.Write(response, 0, response.Length);
            }
            else {
                users[username] = password;
                SaveUsers(users);
                string userDirectory = Path.Combine("Users", username);
                Directory.CreateDirectory(userDirectory);
                // Создание файла Password.txt
                string passwordFilePath = Path.Combine(userDirectory, "Password.txt");
                File.WriteAllText(passwordFilePath, $"{username}\n{password}");
                byte[] response = Encoding.UTF8.GetBytes("REGISTERED");
                stream.Write(response, 0, response.Length);
            }
        }
        static void HandleLogin(string request, NetworkStream stream) {
            string[] parts = request.Split(' ');
            string username = parts[1];
            string password = parts[2];
            var users = LoadUsers();
            if (users.ContainsKey(username) && users[username] == password) {
                byte[] response = Encoding.UTF8.GetBytes("LOGIN_SUCCESS");
                stream.Write(response, 0, response.Length);
            }
            else {
                byte[] response = Encoding.UTF8.GetBytes("LOGIN_FAIL");
                stream.Write(response, 0, response.Length);
            }
        }
        static void HandleUpload(string request, NetworkStream stream) {
            string[] parts = request.Split(' ');
            string username = parts[1];
            string fileName = parts[2];
            int fileDataIndex = request.IndexOf(" ", request.IndexOf(fileName) + fileName.Length) + 1;
            // Извлечение данных файла после команды
            byte[] fileData = Encoding.UTF8.GetBytes(request.Substring(fileDataIndex));
            // Сохрание файла на сервере
            string userDirectory = Path.Combine("Users", username);
            string filePath = Path.Combine(userDirectory, fileName);
            File.WriteAllBytes(filePath, fileData);
            Console.WriteLine($"Файл {fileName} загружен пользователем {username}.");
        }
        static void HandleListFiles(string request, NetworkStream stream) {
            string[] parts = request.Split(' ');
            string username = parts[1];
            string userDirectory = Path.Combine("Users", username);
            string[] files = Directory.GetFiles(userDirectory);
            // Создание строки с именами файлов, разделенными запятыми
            string response = string.Join(",", files.Select(Path.GetFileName));
            byte[] responseBytes = Encoding.UTF8.GetBytes(response);
            stream.Write(responseBytes, 0, responseBytes.Length);
        }
        static void HandleDownload(string request, NetworkStream stream) {
            string[] parts = request.Split(' ');
            string username = parts[1];
            string fileName = parts[2];
            string userDirectory = Path.Combine("Users", username);
            string filePath = Path.Combine(userDirectory, fileName);
            if (File.Exists(filePath)) {
                byte[] fileData = File.ReadAllBytes(filePath);
                stream.Write(fileData, 0, fileData.Length);
            }
            else {
                byte[] response = Encoding.UTF8.GetBytes("FILE_NOT_FOUND");
                stream.Write(response, 0, response.Length);
            }
        }
        static void HandleDelete(string request, NetworkStream stream) {
            string[] parts = request.Split(' ');
            string folder = parts[1];
            string fileName = parts[2];
            string directoryPath = folder == "Share" ? "Users/Share" : Path.Combine("Users", folder);
            string filePath = Path.Combine(directoryPath, fileName);
            // Проверка на защиту от удаления Password.txt и Share.txt
            if ((fileName == "Password.txt" && folder != "Share") || (fileName == "Share.txt" && folder == "Share")) {
                byte[] response = Encoding.UTF8.GetBytes("DELETE_PROHIBITED");
                stream.Write(response, 0, response.Length);
                Console.WriteLine($"Попытка удалить защищенный файл {fileName} отклонена.");
            }
            else if (File.Exists(filePath)) {
                File.Delete(filePath);
                byte[] response = Encoding.UTF8.GetBytes("DELETE_SUCCESS");
                stream.Write(response, 0, response.Length);
                Console.WriteLine($"Файл {fileName} удалён из папки {folder}.");
            }
            else {
                byte[] response = Encoding.UTF8.GetBytes("DELETE_FAIL");
                stream.Write(response, 0, response.Length);
            }
        }
        static Dictionary<string, string> LoadUsers() {
            if (!File.Exists(usersFilePath)) {
                return new Dictionary<string, string>();
            }
            string json = File.ReadAllText(usersFilePath);
            return JsonConvert.DeserializeObject<Dictionary<string, string>>(json);
        }
        static void SaveUsers(Dictionary<string, string> users) {
            string json = JsonConvert.SerializeObject(users, Newtonsoft.Json.Formatting.Indented);
            File.WriteAllText(usersFilePath, json);
        }
    }
}
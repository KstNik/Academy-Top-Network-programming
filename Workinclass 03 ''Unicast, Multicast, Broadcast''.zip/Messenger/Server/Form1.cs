﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Server {
    public partial class ServerForm : Form {
        private TcpListener listener;
        private TcpClient client;
        private NetworkStream stream;
        private struct Subscriptions {
            public bool Ordinary;
            public bool Urgent;
            public bool Important;
        }
        private Subscriptions subscriptions;
        public ServerForm() {
            InitializeComponent();
            StartServer();
            InitializeSubscriptions();
            InitializeComboBox();
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.MaximizeBox = false;
        }
        private void StartServer() {
            try {
                listener = new TcpListener(IPAddress.Any, 12345);
                listener.Start();
                listener.BeginAcceptTcpClient(HandleClient, null);
            }
            catch (Exception ex) {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void HandleClient(IAsyncResult result) {
            try {
                client = listener.EndAcceptTcpClient(result);
                stream = client.GetStream();
                StartReceiving();
            }
            catch (Exception ex) {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void InitializeSubscriptions() {
            subscriptions.Ordinary = false;
            subscriptions.Urgent = false;
            subscriptions.Important = false;
        }
        private bool IsClientSubscribed(string category) {
            switch (category) {
                case "Обычное":
                    return subscriptions.Ordinary;
                case "Срочное":
                    return subscriptions.Urgent;
                case "Важное":
                    return subscriptions.Important;
                default:
                    return false;
            }
        }
        private void buttonSend_Click(object sender, EventArgs e) {
            string category = comboBox.SelectedItem?.ToString();
            if (!string.IsNullOrEmpty(category) && IsClientSubscribed(category)) {
                string message = textBox.Text;
                byte[] data = Encoding.UTF8.GetBytes(message);
                stream.Write(data, 0, data.Length);
                textBox.Clear();
            }
        }
        private void UpdateSubscription(string category, bool subscribed) {
            switch (category) {
                case "Обычное":
                    subscriptions.Ordinary = subscribed;
                    break;
                case "Срочное":
                    subscriptions.Urgent = subscribed;
                    break;
                case "Важное":
                    subscriptions.Important = subscribed;
                    break;
            }
        }
        private void ProcessSubscriptionMessage(string message) {
            string[] parts = message.Split(' ');
            if (parts.Length == 2 && (parts[0] == "Обычное" || parts[0] == "Срочное" || parts[0] == "Важное")) {
                bool subscribed;
                if (bool.TryParse(parts[1], out subscribed)) {
                    UpdateSubscription(parts[0], subscribed);
                }
            }
        }
        private void StartReceiving() {
            byte[] data = new byte[256];
            stream.BeginRead(data, 0, data.Length, ReadCallback, data);
        }
        private void ReadCallback(IAsyncResult result) {
            try {
                int bytesRead = stream.EndRead(result);
                string message = Encoding.UTF8.GetString((byte[])result.AsyncState, 0, bytesRead);
                ProcessSubscriptionMessage(message);
                StartReceiving();
            }
            catch (Exception ex) {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void InitializeComboBox() {
            comboBox.Items.AddRange(new object[] { "Обычное", "Срочное", "Важное" });
            comboBox.SelectedIndex = 0;
        }
    }
}

/*Пошаговая инструкция как создать решение в Visual Studio и подключить к нему серверное и клиентское(ие) 
приложения:
1.  Открыть Visual Studio: Запустить Visual Studio на компьютере.
2.  Создать новый проект: Выбрать "Файл" -> "Создать" -> "Новый проект" из главного меню.
3.  Выбрать тип проекта: В окне "Создать новый проект" выбрать тип проекта. Например "Windows Forms 
    (.NET Framework)".
4.  Указать имя и местоположение: Ввести имя для решения, выбрать местоположение и нажать кнопку "Создать".
5.  Добавить новые проекты к решению:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Добавить" -> "Новый проект";
	• добавить проект "Windows Forms App (.NET Framework)" для серверного и клиентского приложений, 
    и дать им соответствующие имена.
6.  Добавить код в каждый проект.
7.  Установить стартовые проекты:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Свойства";
	• в разделе "Общие" найти опцию "Несколько запускаемых проектов";
	• выбрать "Несколько запускаемых проектов" и установить для каждого проекта соответствующий статус 
    "Запуск", при необходимости изменить очерёдность их запуска.
8.  Запустить решение: Нажать F5 или выбрать "Отладка" -> "Запуск" из главного меню, чтобы запустить 
    решение.
9.  Окно сервера не отображается – запустить его в отдельном потоке:
    public ServerForm() {
        InitializeComponent();
        Task.Run(() => StartServer()); // запуск сервера в отдельном потоке
    }
10. Если исходный проект не нужен, удалить его из решения:
    • щёлкнуть правой кнопкой мыши на проекте в обозревателе решений и выбрать "Удалить";
    • удалить каталог (папку) проекта из каталога (папки) решения.*/

/*Задание 1. Создайте систему рассылки информационных сообщений внутри компании. Система состоит из двух 
приложений. Клиентское приложение используется для получения сообщений. Серверное приложение позволяет 
ввести и разослать сообщение. Клиент и сервер должны быть реализованы в виде консольных приложений. 
Проектируйте сетевую архитектуру системы таким образом, чтобы она не зависела от вида приложения и была 
легко переносима в другой вид приложения.

Задание 2. Добавьте к первому заданию оконный интерфейс клиента.

Задание 3. Добавьте к первому заданию оконный интерфейс для сервера.

Задание 4. Добавьте к первому заданию возможность подписки на конкретный вид сообщений. Клиент определяет, 
какой тип сообщений он готов получать. Сервер рассылает клиентам только те сообщения, на которые они 
подписаны.*/
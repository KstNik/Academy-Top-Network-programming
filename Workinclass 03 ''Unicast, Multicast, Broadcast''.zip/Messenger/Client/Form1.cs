﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Client {
    public partial class ClientForm : Form {
        private TcpClient client;
        private NetworkStream stream;
        private Thread receiveThread;
        public ClientForm() {
            InitializeComponent();
            receiveThread = new Thread(new ThreadStart(ConnectToServer));
            receiveThread.Start();
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.MaximizeBox = false;
        }
        private void ConnectToServer() {
            try {
                client = new TcpClient("127.0.0.1", 12345);
                stream = client.GetStream();
                StartReceiving();
            }
            catch (Exception ex) {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void StartReceiving() {
            byte[] data = new byte[256];
            while (true) {
                int bytes = stream.Read(data, 0, data.Length);
                string message = Encoding.UTF8.GetString(data, 0, bytes);
                Invoke(new Action(() => {
                    textBox.AppendText(message + Environment.NewLine);
                }));
            }
        }
        private void SendSubscriptionMessage(string category, bool subscribed) {
            string message = category + " " + subscribed.ToString();
            byte[] data = Encoding.UTF8.GetBytes(message);
            stream.Write(data, 0, data.Length);
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e) {
            SendSubscriptionMessage("Обычное", checkBox1.Checked);
        }
        private void checkBox2_CheckedChanged(object sender, EventArgs e) {
            SendSubscriptionMessage("Срочное", checkBox2.Checked);
        }
        private void checkBox3_CheckedChanged(object sender, EventArgs e) {
            SendSubscriptionMessage("Важное", checkBox3.Checked);
        }
    }
}

/*Пошаговая инструкция как создать решение в Visual Studio и подключить к нему серверное и клиентское(ие) 
приложения:
1.  Открыть Visual Studio: Запустить Visual Studio на компьютере.
2.  Создать новый проект: Выбрать "Файл" -> "Создать" -> "Новый проект" из главного меню.
3.  Выбрать тип проекта: В окне "Создать новый проект" выбрать тип проекта. Например "Windows Forms 
    (.NET Framework)".
4.  Указать имя и местоположение: Ввести имя для решения, выбрать местоположение и нажать кнопку "Создать".
5.  Добавить новые проекты к решению:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Добавить" -> "Новый проект";
	• добавить проект "Windows Forms App (.NET Framework)" для серверного и клиентского приложений, 
    и дать им соответствующие имена.
6.  Добавить код в каждый проект.
7.  Установить стартовые проекты:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Свойства";
	• в разделе "Общие" найти опцию "Несколько запускаемых проектов";
	• выбрать "Несколько запускаемых проектов" и установить для каждого проекта соответствующий статус 
    "Запуск", при необходимости изменить очерёдность их запуска.
8.  Запустить решение: Нажать F5 или выбрать "Отладка" -> "Запуск" из главного меню, чтобы запустить 
    решение.
9.  Окно сервера не отображается – запустить его в отдельном потоке:
    public ServerForm() {
        InitializeComponent();
        Task.Run(() => StartServer()); // запуск сервера в отдельном потоке
    }
10. Если исходный проект не нужен, удалить его из решения:
    • щёлкнуть правой кнопкой мыши на проекте в обозревателе решений и выбрать "Удалить";
    • удалить каталог (папку) проекта из каталога (папки) решения.*/

/*Задание 1. Создайте систему рассылки информационных сообщений внутри компании. Система состоит из двух 
приложений. Клиентское приложение используется для получения сообщений. Серверное приложение позволяет 
ввести и разослать сообщение. Клиент и сервер должны быть реализованы в виде консольных приложений. 
Проектируйте сетевую архитектуру системы таким образом, чтобы она не зависела от вида приложения и была 
легко переносима в другой вид приложения.

Задание 2. Добавьте к первому заданию оконный интерфейс клиента.

Задание 3. Добавьте к первому заданию оконный интерфейс для сервера.

Задание 4. Добавьте к первому заданию возможность подписки на конкретный вид сообщений. Клиент определяет, 
какой тип сообщений он готов получать. Сервер рассылает клиентам только те сообщения, на которые они 
подписаны.*/
﻿namespace ClientApp
{
    partial class ClientForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxLog = new System.Windows.Forms.TextBox();
            this.buttonGetDate = new System.Windows.Forms.Button();
            this.buttonGetTime = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxLog
            // 
            this.textBoxLog.Location = new System.Drawing.Point(12, 12);
            this.textBoxLog.Multiline = true;
            this.textBoxLog.Name = "textBoxLog";
            this.textBoxLog.Size = new System.Drawing.Size(340, 397);
            this.textBoxLog.TabIndex = 0;
            // 
            // buttonGetDate
            // 
            this.buttonGetDate.Location = new System.Drawing.Point(88, 415);
            this.buttonGetDate.Name = "buttonGetDate";
            this.buttonGetDate.Size = new System.Drawing.Size(75, 23);
            this.buttonGetDate.TabIndex = 1;
            this.buttonGetDate.Text = "GetDate";
            this.buttonGetDate.UseVisualStyleBackColor = true;
            this.buttonGetDate.Click += new System.EventHandler(this.buttonGetDate_Click);
            // 
            // buttonGetTime
            // 
            this.buttonGetTime.Location = new System.Drawing.Point(195, 415);
            this.buttonGetTime.Name = "buttonGetTime";
            this.buttonGetTime.Size = new System.Drawing.Size(75, 23);
            this.buttonGetTime.TabIndex = 2;
            this.buttonGetTime.Text = "GetTime";
            this.buttonGetTime.UseVisualStyleBackColor = true;
            this.buttonGetTime.Click += new System.EventHandler(this.buttonGetTime_Click);
            // 
            // ClientForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(364, 441);
            this.Controls.Add(this.buttonGetTime);
            this.Controls.Add(this.buttonGetDate);
            this.Controls.Add(this.textBoxLog);
            this.Name = "ClientForm";
            this.Text = "Client";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxLog;
        private System.Windows.Forms.Button buttonGetDate;
        private System.Windows.Forms.Button buttonGetTime;
    }
}


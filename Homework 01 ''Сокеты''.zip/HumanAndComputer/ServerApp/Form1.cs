﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace ServerApp {
    public partial class ServerForm : Form {
        TcpListener listener;
        TcpClient client;
        NetworkStream stream;
        Thread thread;
        System.Windows.Forms.Timer timer;
        string[] computerMessages = new string[] { "Привет", "Как дела?", "Погода сегодня отличная", "Bye" };
        Random random = new Random();
        // событие, возникающее при получении сообщения от клиента
        public event EventHandler<string> MessageReceivedFromClient;
        public ServerForm() {
            InitializeComponent();
            MessageReceivedFromClient += OnMessageReceivedFromClient; // подписка на событие
            timer = new System.Windows.Forms.Timer();
            timer.Interval = 30000; // 30 секунд
            timer.Tick += Timer_Tick;
        }
        private void OnMessageReceivedFromClient(object sender, string message) {
            UpdateTextBoxFromClient(message);
        }
        private void Timer_Tick(object sender, EventArgs e) {
            if (client != null && client.Connected) {
                int index = random.Next(computerMessages.Length);
                string message = computerMessages[index];
                messageTextBox.Clear();
                messageTextBox.Text = message;
                byte[] data = Encoding.UTF8.GetBytes(message);
                stream.Write(data, 0, data.Length);
                if (message.ToLower() == "bye") {
                    // закрытие соединения
                    stream.Close();
                    client.Close();
                    timer.Stop();
                }
            }
        }
        private void ComputerMode_CheckedChanged(object sender, EventArgs e) {
            if (computerCheckBox.Checked) {
                timer.Start();
                SendButton.Enabled = false;
            }
            else {
                timer.Stop();
                SendButton.Enabled = true;
            }
        }
        private void StartButton_Click(object sender, EventArgs e) {
            StartButton.Enabled = false; // блокировка кнопки после первого нажатия
            IPAddress ipAddress = IPAddress.Any;
            int port = 8888;
            listener = new TcpListener(ipAddress, port);
            listener.Start();
            thread = new Thread(ListenForClients);
            thread.Start();
        }
        private void ListenForClients() {
            client = listener.AcceptTcpClient();
            stream = client.GetStream();
            byte[] buffer = new byte[1024];
            int bytesRead;
            try {
                while (client.Connected && (bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0) {
                    string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                    if (message.ToLower() == "bye") {
                        // закрытие соединение
                        stream.Close();
                        client.Close();
                        break; // выход из цикла
                    }
                    MessageReceivedFromClient?.Invoke(this, message);
                }
            }
            catch (Exception ex) {
                MessageBox.Show("Ошибка при чтении сообщений: " + ex.Message);
            }
            finally {
                if (stream != null)
                    stream.Close();
                if (client != null)
                    client.Close();
                listener.Stop();
            }
        }
        private void UpdateTextBoxFromClient(string message) {
            if (messageTextBox.InvokeRequired) {
                messageTextBox.Invoke((MethodInvoker)delegate {
                    messageTextBox.AppendText("Сообщение от клиента: " + message + Environment.NewLine);
                });
            }
            else {
                messageTextBox.AppendText("Сообщение от клиента: " + message + Environment.NewLine);
            }
        }
        private void SendButton_Click(object sender, EventArgs e) {
            if (client != null && client.Connected) {
                string message = messageTextBox.Text;
                byte[] data = Encoding.UTF8.GetBytes(message);
                stream.Write(data, 0, data.Length);
                if (message.ToLower() == "bye") {
                    // закрытие соединения
                    stream.Close();
                    client.Close();
                }
            }
            else {
                MessageBox.Show("Не удалось отправить сообщение: клиент не подключен.");
            }
        }
    }
}

/*Пошаговая инструкция как создать решение в Visual Studio и подключить к нему серверное и клиентское(ие) 
приложения:
1.  Открыть Visual Studio: Запустить Visual Studio на компьютере.
2.  Создать новый проект: Выбрать "Файл" -> "Создать" -> "Новый проект" из главного меню.
3.  Выбрать тип проекта: В окне "Создать новый проект" выбрать тип проекта. Например "Windows Forms 
    (.NET Framework)".
4.  Указать имя и местоположение: Ввести имя для решения, выбрать местоположение и нажать кнопку "Создать".
5.  Добавить новые проекты к решению:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Добавить" -> "Новый проект";
	• добавить проект "Windows Forms App (.NET Framework)" для серверного и клиентского приложений, 
    и дать им соответствующие имена.
6.  Добавить код в каждый проект.
7.  Установить стартовые проекты:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Свойства";
	• в разделе "Общие" найти опцию "Несколько запускаемых проектов";
	• выбрать "Несколько запускаемых проектов" и установить для каждого проекта соответствующий статус 
    "Запуск", при необходимости изменить очерёдность их запуска.
8.  Запустить решение: Нажать F5 или выбрать "Отладка" -> "Запуск" из главного меню, чтобы запустить 
    решение.
9.  Окно сервера не отображается – запустить его в отдельном потоке:
    public ServerForm() {
        InitializeComponent();
        Task.Run(() => StartServer()); // запуск сервера в отдельном потоке
    }
10. Если исходный проект не нужен, удалить его из решения:
    • щёлкнуть правой кнопкой мыши на проекте в обозревателе решений и выбрать "Удалить";
    • удалить каталог (папку) проекта из каталога (папки) решения.*/

/*Задание 3. Создайте набор оконных приложений. Первое приложение - сервер, второе приложение клиент. 
Пользователь вводит в элементы управления информацию об IP-адресе для подсоединения и номере порта. После 
нажатия на кнопку Подсоединиться клиент подключается к серверу. Если соединение успешно, клиент и сервер 
могут обмениваться сообщениями до тех пор, пока один из них не попрощается, послав строку Bye. После 
отсылки этой строки, соединение должно быть закончено. Реализуйте несколько режимов отсылки сообщений:
▪ Человек (в клиентском приложении человек вводит строку) – человек (в серверном приложении человек 
вводит строку);
▪ Человек (клиент) – компьютер (сервер);
▪ Компьютер (клиент) – человек (сервер);
▪ Компьютер (клиент) – компьютер (сервер).
Для реализации ответов компьютера используйте набор заготовленных фраз, выбранных случайным образом.
Проектируйте архитектуру вашего приложения таким образом, чтобы сетевой блок кода не был завязан на UI. 
Например, чтобы его было просто перенести из оконного в консольное приложение.*/
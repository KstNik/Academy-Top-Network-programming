﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Drawing;
using System.IO;

namespace Server {
    public partial class ServerForm : Form {
        private UdpClient udpServer;
        private const int listenPort = 11000;
        private Dictionary<string, (int Count, DateTime LastRequestTime, DateTime LastActiveTime)> clientRequestInfo = new Dictionary<string, (int, DateTime, DateTime)>();
        private int connectedClientsCount = 0;
        private IPEndPoint clientEndPoint; // переменная для хранения клиентского адреса
        public ServerForm() {
            InitializeComponent();
            StartServer();
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink; // запрет изменения размера
            this.MaximizeBox = false; // запрет развёртывания на весь экран
            // запуск таймера для проверки неактивных клиентов каждую минуту
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Tick += (sender, e) => CheckInactiveClients(null);
            timer.Interval = 60000; // 60000 миллисекунд = 1 минута
            timer.Start();
        }
        private void StartServer() {
            udpServer = new UdpClient(listenPort);
            Log("Сервер запущен...");
            udpServer.BeginReceive(new AsyncCallback(ReceiveCallback), null);
        }
        private void ReceiveCallback(IAsyncResult ar) {
            IPEndPoint clientEndPoint = new IPEndPoint(IPAddress.Any, listenPort);
            byte[] receivedBytes = udpServer.EndReceive(ar, ref clientEndPoint);
            string receivedData = Encoding.UTF8.GetString(receivedBytes);
            Log($"Получено: {receivedData} от {clientEndPoint}");
            string clientId = receivedData.Split(':')[0].Trim();
            string response;
            this.clientEndPoint = clientEndPoint;
            if (connectedClientsCount >= 2 && !clientRequestInfo.ContainsKey(clientId)) {
                Log("Превышено максимальное количество подключенных клиентов. Новое подключение отклонено.");
                response = "Превышено максимальное количество подключённых клиентов. Новое подключение отклонено.";
                byte[] responseBytes = Encoding.UTF8.GetBytes(response);
                udpServer.Send(responseBytes, responseBytes.Length, clientEndPoint);
                udpServer.BeginReceive(new AsyncCallback(ReceiveCallback), null);
                return;
            }
            if (clientRequestInfo.ContainsKey(clientId)) {
                var info = clientRequestInfo[clientId];
                clientRequestInfo[clientId] = (info.Count, info.LastRequestTime, DateTime.Now);
            }
            else {
                connectedClientsCount++;
                clientRequestInfo.Add(clientId, (0, DateTime.MinValue, DateTime.Now));
            }
            if (CheckRequestLimit(clientId)) {
                response = ProcessRequest(receivedData);
            }
            else {
                response = "Превышено ограничение на количество запросов. Попробуйте позже.";
            }
            byte[] responseBytesFinal = Encoding.UTF8.GetBytes(response);
            udpServer.Send(responseBytesFinal, responseBytesFinal.Length, clientEndPoint);
            udpServer.BeginReceive(new AsyncCallback(ReceiveCallback), null);
        }
        private bool CheckRequestLimit(string clientId) {
            if (!clientRequestInfo.ContainsKey(clientId)) {
                clientRequestInfo.Add(clientId, (0, DateTime.MinValue, DateTime.Now));
            }
            var info = clientRequestInfo[clientId];
            if ((DateTime.Now - info.LastRequestTime).TotalMinutes < 1) {
                if (info.Count >= 10) {
                    return false;
                }
            }
            else {
                clientRequestInfo[clientId] = (0, DateTime.Now, DateTime.Now);
            }
            clientRequestInfo[clientId] = (info.Count + 1, DateTime.Now, info.LastActiveTime);
            return true;
        }
        private string ProcessRequest(string data) {
            // рецепты
            var recipes = new Dictionary<string, (string, string)> {
                {"картофель, сыр", ("Картофель запеченный с сыром", "potato_cheese.jpeg")},
                {"томат, огурец", ("Овощной салат", "vegetable_salad.jpeg")}
            };
            foreach (var entry in recipes) {
                if (data.Contains(entry.Key)) {
                    // отправка рецепта и изображения
                    SendRecipeWithImage(entry.Value.Item1, entry.Value.Item2);
                    return $"Рецепт для {entry.Key}: {entry.Value.Item1}";
                }
            }
            return "Рецепт не найден.";
        }
        private void SendRecipeWithImage(string recipe, string imageName) {
            byte[] recipeBytes = Encoding.UTF8.GetBytes(recipe);
            // отправка рецепта
            udpServer.Send(recipeBytes, recipeBytes.Length, clientEndPoint);
            // отправка изображения
            byte[] imageBytes = File.ReadAllBytes(imageName);
            udpServer.Send(imageBytes, imageBytes.Length, clientEndPoint);
        }
        private void Log(string message) {
            string logMessage = $"{DateTime.Now}: {message}";
            if (textBoxLogs.InvokeRequired) {
                textBoxLogs.Invoke((MethodInvoker)delegate {
                    textBoxLogs.AppendText(logMessage + Environment.NewLine);
                });
            }
            else {
                textBoxLogs.AppendText(logMessage + Environment.NewLine);
            }
        }
        private void ServerForm_FormClosing(object sender, FormClosingEventArgs e) {
            udpServer.Close();
        }
        private void CheckInactiveClients(object state) {
            var inactiveClients = clientRequestInfo.Where(kvp => (DateTime.Now - kvp.Value.LastActiveTime).TotalMinutes >= 10).ToList();
            foreach (var client in inactiveClients) {
                clientRequestInfo.Remove(client.Key);
                connectedClientsCount--;
                Log($"Клиент {client.Key} отключен из-за неактивности.");
            }
        }
    }
}

/*Пошаговая инструкция как создать решение в Visual Studio и подключить к нему серверное и клиентское(ие) 
приложения:
1.  Открыть Visual Studio: Запустить Visual Studio на компьютере.
2.  Создать новый проект: Выбрать "Файл" -> "Создать" -> "Новый проект" из главного меню.
3.  Выбрать тип проекта: В окне "Создать новый проект" выбрать тип проекта. Например "Windows Forms 
    (.NET Framework)".
4.  Указать имя и местоположение: Ввести имя для решения, выбрать местоположение и нажать кнопку "Создать".
5.  Добавить новые проекты к решению:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Добавить" -> "Новый проект";
	• добавить проект "Windows Forms App (.NET Framework)" для серверного и клиентского приложений, 
    и дать им соответствующие имена.
6.  Добавить код в каждый проект.
7.  Установить стартовые проекты:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Свойства";
	• в разделе "Общие" найти опцию "Несколько запускаемых проектов";
	• выбрать "Несколько запускаемых проектов" и установить для каждого проекта соответствующий статус 
    "Запуск", при необходимости изменить очерёдность их запуска.
8.  Запустить решение: Нажать F5 или выбрать "Отладка" -> "Запуск" из главного меню, чтобы запустить 
    решение.
9.  Окно сервера не отображается – запустить его в отдельном потоке:
    public ServerForm() {
        InitializeComponent();
        Task.Run(() => StartServer()); // запуск сервера в отдельном потоке
    }
10. Если исходный проект не нужен, удалить его из решения:
    • щёлкнуть правой кнопкой мыши на проекте в обозревателе решений и выбрать "Удалить";
    • удалить каталог (папку) проекта из каталога (папки) решения.*/

/*Задание 1. Создайте серверное приложение с помощью, которого можно узнавать кулинарные рецепты. 
Типичный пример работы:
▪ клиентское приложение подключается к серверу;
▪ клиентское приложение посылает запрос с указанием списка продуктов;
▪ сервер возвращает рецепты, содержащие указанные продукты;
▪ клиент может послать новый запрос или отключиться.
Одновременно к серверу может быть подключено большое количество клиентов. Используйте UDP 
сокеты для решения этой задачи.

Задание 2. Добавьте к первому заданию ограничение по количеству запросов для конкретного 
клиента за определённый промежуток времени. Например, клиент не может послать больше, 
чем 10 запросов за час.

Задание 3. Добавьте к первому заданию ограничение по количеству, одновременно подключённых 
клиентов. Если какой-то клиент не активен в течение 10 минут он должен быть отключён.

Задание 4. Добавьте оконный интерфейс для управления сервером. Также добавьте оконный интерфейс 
для управления клиентом.

Задание 5. Добавьте механизм логгирования в сервер. Этот механизм должны сохранять информацию 
о клиентах, их запросах, времени соединения и т.д.

Задание 6. Добавьте в ответ сервера картинку финального блюда. Например, если сервер возвращает 
рецепт салата Цезарь, нужно послать клиенту сам рецепт, а также изображение уже готового салата 
Цезарь.*/
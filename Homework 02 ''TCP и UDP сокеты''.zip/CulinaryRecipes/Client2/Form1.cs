﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.IO;

namespace Client2 {
    public partial class ClientForm : Form {
        private UdpClient udpClient;
        private const int serverPort = 11000;
        private const string serverIP = "127.0.0.1";
        private bool isConnected = false;
        public ClientForm() {
            InitializeComponent();
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink; // запрет изменения размера
            this.MaximizeBox = false; // запрет развёртывания на весь экран
            udpClient = new UdpClient();
            // отображаемые продукты
            comboBoxProducts.Items.Add("картофель, сыр");
            comboBoxProducts.Items.Add("томат, огурец");
            comboBoxProducts.SelectedIndex = 0;
        }
        private void InitializeUdpClient() {
            udpClient = new UdpClient();
        }
        private void btnToggleConnection_Click(object sender, EventArgs e) {
            if (!isConnected) {
                try {
                    InitializeUdpClient(); // инициализация нового UdpClient
                    udpClient.Connect(serverIP, serverPort);
                    isConnected = true;
                    Log("Подключено к серверу.");
                }
                catch (Exception ex) {
                    Log("Ошибка подключения: " + ex.Message);
                }
            }
            else {
                udpClient.Close();
                isConnected = false;
                Log("Отключено от сервера.");
            }
        }
        private void btnSend_Click(object sender, EventArgs e) {
            string clientId = "Client2"; // уникальный идентификатор клиента
            string message = clientId + ": " + comboBoxProducts.SelectedItem.ToString(); // сообщение с ID клиента и продуктами
            byte[] bytesToSend = Encoding.UTF8.GetBytes(message);
            try {
                udpClient.Close();
                InitializeUdpClient();
                udpClient.Connect(serverIP, serverPort);
                // отправка сообщения на сервер
                udpClient.Send(bytesToSend, bytesToSend.Length);
                // получение ответа от сервера
                IPEndPoint serverEndPoint = new IPEndPoint(IPAddress.Any, 0);
                byte[] receivedBytes = udpClient.Receive(ref serverEndPoint);
                string receivedData = Encoding.UTF8.GetString(receivedBytes);
                // отображение ответа сервера в текстовом поле
                textBoxOutput.Text = receivedData;
                // получение изображения
                receivedBytes = udpClient.Receive(ref serverEndPoint);
                Image receivedImage = Image.FromStream(new MemoryStream(receivedBytes));
                // вывод изображения
                pictureBoxRecipe.Image = receivedImage;
                Log("Отправка запроса успешно завершена.");
            }
            catch (Exception ex) {
                Log("Ошибка отправки запроса: " + ex.Message);
            }
        }
        private void Log(string message) {
            textBoxLogs.AppendText(message + Environment.NewLine);
        }
    }
}

/*Пошаговая инструкция как создать решение в Visual Studio и подключить к нему серверное и клиентское(ие) 
приложения:
1.  Открыть Visual Studio: Запустить Visual Studio на компьютере.
2.  Создать новый проект: Выбрать "Файл" -> "Создать" -> "Новый проект" из главного меню.
3.  Выбрать тип проекта: В окне "Создать новый проект" выбрать тип проекта. Например "Windows Forms 
    (.NET Framework)".
4.  Указать имя и местоположение: Ввести имя для решения, выбрать местоположение и нажать кнопку "Создать".
5.  Добавить новые проекты к решению:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Добавить" -> "Новый проект";
	• добавить проект "Windows Forms App (.NET Framework)" для серверного и клиентского приложений, 
    и дать им соответствующие имена.
6.  Добавить код в каждый проект.
7.  Установить стартовые проекты:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Свойства";
	• в разделе "Общие" найти опцию "Несколько запускаемых проектов";
	• выбрать "Несколько запускаемых проектов" и установить для каждого проекта соответствующий статус 
    "Запуск", при необходимости изменить очерёдность их запуска.
8.  Запустить решение: Нажать F5 или выбрать "Отладка" -> "Запуск" из главного меню, чтобы запустить 
    решение.
9.  Окно сервера не отображается – запустить его в отдельном потоке:
    public ServerForm() {
        InitializeComponent();
        Task.Run(() => StartServer()); // запуск сервера в отдельном потоке
    }
10. Если исходный проект не нужен, удалить его из решения:
    • щёлкнуть правой кнопкой мыши на проекте в обозревателе решений и выбрать "Удалить";
    • удалить каталог (папку) проекта из каталога (папки) решения.*/

/*Задание 1. Создайте серверное приложение с помощью, которого можно узнавать кулинарные рецепты. 
Типичный пример работы:
▪ клиентское приложение подключается к серверу;
▪ клиентское приложение посылает запрос с указанием списка продуктов;
▪ сервер возвращает рецепты, содержащие указанные продукты;
▪ клиент может послать новый запрос или отключиться.
Одновременно к серверу может быть подключено большое количество клиентов. Используйте UDP 
сокеты для решения этой задачи.

Задание 2. Добавьте к первому заданию ограничение по количеству запросов для конкретного 
клиента за определённый промежуток времени. Например, клиент не может послать больше, 
чем 10 запросов за час.

Задание 3. Добавьте к первому заданию ограничение по количеству, одновременно подключённых 
клиентов. Если какой-то клиент не активен в течение 10 минут он должен быть отключён.

Задание 4. Добавьте оконный интерфейс для управления сервером. Также добавьте оконный интерфейс 
для управления клиентом.

Задание 5. Добавьте механизм логгирования в сервер. Этот механизм должны сохранять информацию 
о клиентах, их запросах, времени соединения и т.д.

Задание 6. Добавьте в ответ сервера картинку финального блюда. Например, если сервер возвращает 
рецепт салата Цезарь, нужно послать клиенту сам рецепт, а также изображение уже готового салата 
Цезарь.*/
﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace Client1 {
    class Program {
        static Random random = new Random();
        // учётные данные (имя пользователя и пароль)
        static string username = "user1";
        static string password = "1111";
        static void Main(string[] args) {
            try {
                bool connected = false;
                while (!connected) {
                    try {
                        TcpClient clientSocket = new TcpClient();
                        clientSocket.Connect("localhost", 8888);
                        connected = true;
                        Console.WriteLine("Подключение к серверу...");
                        NetworkStream networkStream = clientSocket.GetStream();
                        // автоматическая отправка учётных данных на сервер
                        string credentials = $"{username}:{password}";
                        byte[] bytesToSend = Encoding.UTF8.GetBytes(credentials);
                        networkStream.Write(bytesToSend, 0, bytesToSend.Length);
                        // ответ от сервера о результате аутентификации
                        byte[] authResponseBytes = new byte[1024];
                        int authResponseLength = networkStream.Read(authResponseBytes, 0, authResponseBytes.Length);
                        string authResponse = Encoding.UTF8.GetString(authResponseBytes, 0, authResponseLength);
                        if (authResponse.Equals("authenticated")) {
                            int requestCounter = 0;
                            while (requestCounter < 3) {
                                SendRequest(networkStream);
                                requestCounter++;
                            }
                        }
                        else {
                            Console.WriteLine("Ошибка аутентификации. Проверьте имя пользователя и пароль.");
                        }
                        networkStream.Close();
                        clientSocket.Close();
                    }
                    catch (SocketException ex)
                    {
                        Console.WriteLine($"Ошибка подключения к серверу: {ex.Message}");
                        int retryInterval = random.Next(15000, 20001); // случайный интервал от 15 до 20 секунд
                        Console.WriteLine($"Повторная попытка подключения через {retryInterval / 1000} секунд...");
                        Thread.Sleep(retryInterval);
                    }
                }
            }
            catch (Exception ex) {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
            Console.WriteLine("Нажмите любую клавишу для выхода...");
            Console.ReadKey();
        }
        static void SendRequest(NetworkStream networkStream) {
            string request = "request";
            byte[] bytesToSend = Encoding.UTF8.GetBytes(request);
            networkStream.Write(bytesToSend, 0, bytesToSend.Length);
            networkStream.Flush();
            byte[] bytesFrom = new byte[1024];
            int bytesRead = networkStream.Read(bytesFrom, 0, bytesFrom.Length);
            string quote = Encoding.UTF8.GetString(bytesFrom, 0, bytesRead);
            Console.WriteLine("Получено сообщение от сервера: " + quote);
            int interval = random.Next(3000, 10001); // случайный интервал от 3 до 10 секунд
            Thread.Sleep(interval);
        }
    }
}

/*Пошаговая инструкция как создать решение в Visual Studio и подключить к нему серверное и клиентское(ие) 
приложения:
1.  Открыть Visual Studio: Запустить Visual Studio на компьютере.
2.  Создать новый проект: Выбрать "Файл" -> "Создать" -> "Новый проект" из главного меню.
3.  Выбрать тип проекта: В окне "Создать новый проект" выбрать тип проекта. Например "Windows Forms 
    (.NET Framework)".
4.  Указать имя и местоположение: Ввести имя для решения, выбрать местоположение и нажать кнопку "Создать".
5.  Добавить новые проекты к решению:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Добавить" -> "Новый проект";
	• добавить проект "Windows Forms App (.NET Framework)" для серверного и клиентского приложений, 
    и дать им соответствующие имена.
6.  Добавить код в каждый проект.
7.  Установить стартовые проекты:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Свойства";
	• в разделе "Общие" найти опцию "Несколько запускаемых проектов";
	• выбрать "Несколько запускаемых проектов" и установить для каждого проекта соответствующий статус 
    "Запуск", при необходимости изменить очерёдность их запуска.
8.  Запустить решение: Нажать F5 или выбрать "Отладка" -> "Запуск" из главного меню, чтобы запустить 
    решение.
9.  Окно сервера не отображается – запустить его в отдельном потоке:
    public ServerForm() {
        InitializeComponent();
        Task.Run(() => StartServer()); // запуск сервера в отдельном потоке
    }
10. Если исходный проект не нужен, удалить его из решения:
    • щёлкнуть правой кнопкой мыши на проекте в обозревателе решений и выбрать "Удалить";
    • удалить каталог (папку) проекта из каталога (папки) решения.*/

/*Задание 1. Создайте серверное приложение «Генератор цитат» и клиента для получения данных. 
При запросе клиента, серверное приложение должно вернуть случайную цитату. Процесс должен 
продолжаться до тех пор, пока клиент не захочет отсоединиться. К одному серверу в один момент 
времени может быть подключено большое количество клиентов. Сервер ведёт лог соединений:
▪ Кто подключился;
▪ Когда подключился;
▪ Набор цитат;
▪ Время отключения.
Клиентское приложение отображает пользователю полученные цитаты. Архитектура вашего приложения 
должна быть построена без привязки сетевой части к UI. Это означает, что сетевой блок кода 
может быть легко перемещён в любой вид приложения: консольное, оконное.

Задание 2. Добавьте к первому заданию ограничение по максимальному количеству цитат для 
пользователя. Когда количество достигнуто, сервер сообщает клиенту об этом и рвёт соединение.

Задание 3. Добавьте к первому заданию ограничение на максимальное количество подключённых 
клиентов. Когда количество достигнуто, при попытке нового подключения сервер сообщает клиенту, 
что он сейчас находится под максимальной нагрузкой и необходимо попробовать подключиться через 
какое-то время.

Задание 4. Добавьте к первому заданию пароль и имя пользователя для подключения. Если пароль 
и имя пользователя неизвестны, клиент подключиться не может.*/
﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace Server {
    class Program {
        // учётные записи пользователей и паролей
        static Dictionary<string, string> userCredentials = new Dictionary<string, string>() {
            {"user1", "1111"}, {"user2", "2222"}, {"user3", "3333"}, {"user4", "4444"}};
        static List<string> quotes = new List<string>() { "Идущие на смерть приветствуют тебя!",
            "Фортуна помогает смелым.", "И ты Брут, с ними?", "Разделяй и властвуй.", "Жребий брошен.", };
        static List<ClientHandler> clients = new List<ClientHandler>();
        static int clientCounter = 1;
        static int maxClients = 3; // максимальное количество клиентов
        static Random random = new Random();
        static Mutex mutex = new Mutex();
        static void Main(string[] args) {
            TcpListener serverSocket = new TcpListener(IPAddress.Any, 8888);
            serverSocket.Start();
            Console.WriteLine("Сервер запущен...");
            while (true) {
                if (clients.Count < maxClients) {
                    TcpClient clientSocket = serverSocket.AcceptTcpClient();
                    Console.WriteLine($"Подключен клиент {clientCounter} в {DateTime.Now}");
                    if (AuthenticateClient(clientSocket)) { // аутентификация
                        ClientHandler client = new ClientHandler(clientSocket, clientCounter.ToString());
                        clients.Add(client);
                        Thread clientThread = new Thread(new ThreadStart(client.HandleClient));
                        clientThread.Start();
                        clientCounter++;
                    }
                    else {
                        clientSocket.Close();
                    }
                }
                else {
                    TcpClient tempClientSocket = serverSocket.AcceptTcpClient();
                    NetworkStream tempNetworkStream = tempClientSocket.GetStream();
                    string maxLoadMessage = "Сервер находится под максимальной нагрузкой. Попробуйте подключиться позже.";
                    byte[] maxLoadBytes = Encoding.UTF8.GetBytes(maxLoadMessage);
                    tempNetworkStream.Write(maxLoadBytes, 0, maxLoadBytes.Length);
                    tempNetworkStream.Close();
                    tempClientSocket.Close();
                    continue;
                }
            }
        }
        static bool AuthenticateClient(TcpClient clientSocket) {
            NetworkStream networkStream = clientSocket.GetStream();
            byte[] bytesFrom = new byte[1024];
            int bytesRead = networkStream.Read(bytesFrom, 0, bytesFrom.Length);
            string credentials = Encoding.UTF8.GetString(bytesFrom, 0, bytesRead);
            string[] parts = credentials.Split(':');
            if (parts.Length == 2 && userCredentials.ContainsKey(parts[0]) && userCredentials[parts[0]] == parts[1]) {
                byte[] authSuccessMessage = Encoding.UTF8.GetBytes("authenticated");
                networkStream.Write(authSuccessMessage, 0, authSuccessMessage.Length);
                return true;
            }
            else {
                byte[] authFailureMessage = Encoding.UTF8.GetBytes("authentication_failed");
                networkStream.Write(authFailureMessage, 0, authFailureMessage.Length);
                return false;
            }
        }
        public static string GetRandomQuote() {
            int index = random.Next(quotes.Count);
            return quotes[index];
        }
        public static void RemoveClient(ClientHandler client) {
            mutex.WaitOne();
            clients.Remove(client);
            mutex.ReleaseMutex();
        }
        public static void LogMessage(string message) {
            Console.WriteLine(message);
        }
    }
    public class ClientHandler {
        private TcpClient clientSocket;
        private NetworkStream networkStream;
        private string clientID;
        private int requestCounter = 0;
        public ClientHandler(TcpClient clientSocket, string clientID) {
            this.clientSocket = clientSocket;
            networkStream = clientSocket.GetStream();
            this.clientID = clientID;
        }
        public void HandleClient() {
            Program.LogMessage($"Клиент {clientID} подключился.");
            while (requestCounter < 3) {
                try {
                    byte[] bytesFrom = new byte[1024];
                    int bytesRead = networkStream.Read(bytesFrom, 0, bytesFrom.Length);
                    string dataFromClient = Encoding.UTF8.GetString(bytesFrom, 0, bytesRead);
                    if (dataFromClient.Equals("disconnect")) {
                        Program.LogMessage($"Клиент {clientID} отправил запрос на отключение.");
                        break;
                    }
                    string quote = Program.GetRandomQuote();
                    byte[] bytesToSend = Encoding.UTF8.GetBytes(quote);
                    networkStream.Write(bytesToSend, 0, bytesToSend.Length);
                    networkStream.Flush();
                    Program.LogMessage($"Отправлено сообщение клиенту {clientID} в {DateTime.Now}: {quote}");
                    requestCounter++;
                }
                catch (Exception ex) {
                    Program.LogMessage($"Ошибка при обработке запроса от клиента {clientID}: {ex.Message}");
                    break;
                }
            }
            Program.LogMessage($"Клиент {clientID} отключился в {DateTime.Now}.");
            networkStream.Close();
            clientSocket.Close();
            Program.RemoveClient(this);
        }
    }
}

/*Пошаговая инструкция как создать решение в Visual Studio и подключить к нему серверное и клиентское(ие) 
приложения:
1.  Открыть Visual Studio: Запустить Visual Studio на компьютере.
2.  Создать новый проект: Выбрать "Файл" -> "Создать" -> "Новый проект" из главного меню.
3.  Выбрать тип проекта: В окне "Создать новый проект" выбрать тип проекта. Например "Windows Forms 
    (.NET Framework)".
4.  Указать имя и местоположение: Ввести имя для решения, выбрать местоположение и нажать кнопку "Создать".
5.  Добавить новые проекты к решению:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Добавить" -> "Новый проект";
	• добавить проект "Windows Forms App (.NET Framework)" для серверного и клиентского приложений, 
    и дать им соответствующие имена.
6.  Добавить код в каждый проект.
7.  Установить стартовые проекты:
	• щёлкнуть правой кнопкой мыши на решении в обозревателе решений;
	• выбрать "Свойства";
	• в разделе "Общие" найти опцию "Несколько запускаемых проектов";
	• выбрать "Несколько запускаемых проектов" и установить для каждого проекта соответствующий статус 
    "Запуск", при необходимости изменить очерёдность их запуска.
8.  Запустить решение: Нажать F5 или выбрать "Отладка" -> "Запуск" из главного меню, чтобы запустить 
    решение.
9.  Окно сервера не отображается – запустить его в отдельном потоке:
    public ServerForm() {
        InitializeComponent();
        Task.Run(() => StartServer()); // запуск сервера в отдельном потоке
    }
10. Если исходный проект не нужен, удалить его из решения:
    • щёлкнуть правой кнопкой мыши на проекте в обозревателе решений и выбрать "Удалить";
    • удалить каталог (папку) проекта из каталога (папки) решения.*/

/*Задание 1. Создайте серверное приложение «Генератор цитат» и клиента для получения данных. 
При запросе клиента, серверное приложение должно вернуть случайную цитату. Процесс должен 
продолжаться до тех пор, пока клиент не захочет отсоединиться. К одному серверу в один момент 
времени может быть подключено большое количество клиентов. Сервер ведёт лог соединений:
▪ Кто подключился;
▪ Когда подключился;
▪ Набор цитат;
▪ Время отключения.
Клиентское приложение отображает пользователю полученные цитаты. Архитектура вашего приложения 
должна быть построена без привязки сетевой части к UI. Это означает, что сетевой блок кода 
может быть легко перемещён в любой вид приложения: консольное, оконное.

Задание 2. Добавьте к первому заданию ограничение по максимальному количеству цитат для 
пользователя. Когда количество достигнуто, сервер сообщает клиенту об этом и рвёт соединение.

Задание 3. Добавьте к первому заданию ограничение на максимальное количество подключённых 
клиентов. Когда количество достигнуто, при попытке нового подключения сервер сообщает клиенту, 
что он сейчас находится под максимальной нагрузкой и необходимо попробовать подключиться через 
какое-то время.

Задание 4. Добавьте к первому заданию пароль и имя пользователя для подключения. Если пароль 
и имя пользователя неизвестны, клиент подключиться не может.*/